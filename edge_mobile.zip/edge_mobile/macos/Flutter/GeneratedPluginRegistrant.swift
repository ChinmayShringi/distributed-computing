//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import flutter_webrtc

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  FlutterWebRTCPlugin.register(with: registry.registrar(forPlugin: "FlutterWebRTCPlugin"))
}
