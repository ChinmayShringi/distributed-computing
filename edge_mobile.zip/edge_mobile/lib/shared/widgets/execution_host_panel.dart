import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:lucide_icons/lucide_icons.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../theme/app_colors.dart';
import 'glass_container.dart';

class ExecutionHostPanel extends StatefulWidget {
  final List<Map<String, dynamic>> executions;

  const ExecutionHostPanel({super.key, required this.executions});

  @override
  State<ExecutionHostPanel> createState() => _ExecutionHostPanelState();
}

class _ExecutionHostPanelState extends State<ExecutionHostPanel> {
  String? _selectedDevice;

  @override
  Widget build(BuildContext context) {
    final filteredExecutions = _selectedDevice == null
        ? widget.executions
        : widget.executions.where((e) => e['selected_device_id'] == _selectedDevice).toList();

    // Calculate device distribution
    final deviceCounts = <String, int>{};
    for (var exec in widget.executions) {
      final deviceName = exec['selected_device_name'] as String;
      deviceCounts[deviceName] = (deviceCounts[deviceName] ?? 0) + 1;
    }

    // Calculate compute distribution
    final computeCounts = <String, int>{};
    for (var exec in widget.executions) {
      final compute = (exec['host_compute'] as String).toUpperCase();
      computeCounts[compute] = (computeCounts[compute] ?? 0) + 1;
    }

    // Calculate aggregate metrics
    final totalMemory = filteredExecutions.fold<double>(
      0,
      (sum, e) => sum + ((e['resource_usage'] as Map)['memory_used_mb'] as num).toDouble(),
    );
    final avgMemory = filteredExecutions.isEmpty ? 0.0 : totalMemory / filteredExecutions.length;

    final avgCpu = filteredExecutions.isEmpty
        ? 0.0
        : filteredExecutions.fold<double>(
              0,
              (sum, e) {
                final usage = e['resource_usage'] as Map;
                return sum + ((usage['cpu_percent'] ?? 0) as num).toDouble();
              },
            ) /
            filteredExecutions.length;

    final avgTime = filteredExecutions.isEmpty
        ? 0.0
        : filteredExecutions.fold<double>(
              0,
              (sum, e) => sum + ((e['total_time_ms'] ?? 0) as num).toDouble(),
            ) /
            filteredExecutions.length;

    return GlassContainer(
      padding: const EdgeInsets.all(20),
      borderRadius: 20,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'EXECUTION HOST + UTILIZATION',
                style: GoogleFonts.inter(
                  fontSize: 9,
                  fontWeight: FontWeight.w900,
                  color: AppColors.mutedIcon,
                  letterSpacing: 1.5,
                ),
              ),
              if (_selectedDevice != null)
                GestureDetector(
                  onTap: () => setState(() => _selectedDevice = null),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.primaryRed.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: AppColors.primaryRed.withOpacity(0.3)),
                    ),
                    child: Text(
                      'CLEAR FILTER',
                      style: GoogleFonts.inter(
                        fontSize: 8,
                        fontWeight: FontWeight.w900,
                        color: AppColors.primaryRed,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ),
            ],
          ),

          const SizedBox(height: 24),

          // Doughnut Charts Row
          Row(
            children: [
              Expanded(
                child: _DeviceDistributionChart(
                  deviceCounts: deviceCounts,
                  selectedDevice: _selectedDevice,
                  onDeviceTap: (deviceId) => setState(() => _selectedDevice = deviceId),
                  executions: widget.executions,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _ComputeDistributionChart(computeCounts: computeCounts),
              ),
            ],
          ),

          const SizedBox(height: 24),

          // Radial Gauges Row
          Row(
            children: [
              Expanded(child: _RadialGauge(label: 'AVG MEMORY', value: avgMemory, unit: 'MB', max: 512)),
              const SizedBox(width: 12),
              Expanded(child: _RadialGauge(label: 'AVG CPU', value: avgCpu, unit: '%', max: 100)),
              const SizedBox(width: 12),
              Expanded(child: _RadialGauge(label: 'AVG TIME', value: avgTime, unit: 'ms', max: 1000)),
            ],
          ),

          const SizedBox(height: 24),

          // Recent Executions Header
          Text(
            'RECENT EXECUTIONS',
            style: GoogleFonts.inter(
              fontSize: 9,
              fontWeight: FontWeight.w900,
              color: AppColors.mutedIcon,
              letterSpacing: 1.5,
            ),
          ),

          const SizedBox(height: 12),

          // Execution Cards
          ...filteredExecutions.take(3).map((exec) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _ExecutionCard(execution: exec),
              )),
        ],
      ),
    );
  }
}

class _DeviceDistributionChart extends StatelessWidget {
  final Map<String, int> deviceCounts;
  final String? selectedDevice;
  final Function(String?) onDeviceTap;
  final List<Map<String, dynamic>> executions;

  const _DeviceDistributionChart({
    required this.deviceCounts,
    required this.selectedDevice,
    required this.onDeviceTap,
    required this.executions,
  });

  @override
  Widget build(BuildContext context) {
    final colors = [AppColors.safeGreen, AppColors.infoBlue, AppColors.warningAmber, AppColors.dangerPink];
    final sections = deviceCounts.entries.take(5).toList().asMap().entries.map((entry) {
      final idx = entry.key;
      final device = entry.value;
      return PieChartSectionData(
        color: colors[idx % colors.length],
        value: device.value.toDouble(),
        title: '${device.value}',
        radius: 50,
        titleStyle: GoogleFonts.jetBrainsMono(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white),
      );
    }).toList();

    return Column(
      children: [
        Text(
          'WHERE EXECUTIONS RAN',
          style: GoogleFonts.inter(fontSize: 8, fontWeight: FontWeight.w900, color: AppColors.textSecondary, letterSpacing: 1),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 140,
          child: PieChart(
            PieChartData(
              sections: sections,
              centerSpaceRadius: 40,
              sectionsSpace: 2,
            ),
          ),
        ),
        const SizedBox(height: 12),
        ...deviceCounts.entries.take(3).map((entry) => Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(
                      entry.key,
                      style: GoogleFonts.inter(fontSize: 9, color: AppColors.textSecondary),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Text(
                    '${entry.value}',
                    style: GoogleFonts.jetBrainsMono(fontSize: 9, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                  ),
                ],
              ),
            )),
      ],
    );
  }
}

class _ComputeDistributionChart extends StatelessWidget {
  final Map<String, int> computeCounts;

  const _ComputeDistributionChart({required this.computeCounts});

  @override
  Widget build(BuildContext context) {
    final colorMap = {
      'CPU': AppColors.infoBlue,
      'GPU': AppColors.safeGreen,
      'NPU': AppColors.warningAmber,
      'UNKNOWN': AppColors.mutedIcon,
    };

    final sections = computeCounts.entries.map((entry) {
      return PieChartSectionData(
        color: colorMap[entry.key] ?? AppColors.mutedIcon,
        value: entry.value.toDouble(),
        title: '${entry.value}',
        radius: 50,
        titleStyle: GoogleFonts.jetBrainsMono(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white),
      );
    }).toList();

    return Column(
      children: [
        Text(
          'COMPUTE USED',
          style: GoogleFonts.inter(fontSize: 8, fontWeight: FontWeight.w900, color: AppColors.textSecondary, letterSpacing: 1),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 140,
          child: PieChart(
            PieChartData(
              sections: sections,
              centerSpaceRadius: 40,
              sectionsSpace: 2,
            ),
          ),
        ),
        const SizedBox(height: 12),
        ...computeCounts.entries.map((entry) => Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: colorMap[entry.key],
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        entry.key,
                        style: GoogleFonts.inter(fontSize: 9, color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                  Text(
                    '${entry.value}',
                    style: GoogleFonts.jetBrainsMono(fontSize: 9, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                  ),
                ],
              ),
            )),
      ],
    );
  }
}

class _RadialGauge extends StatelessWidget {
  final String label;
  final double value;
  final String unit;
  final double max;

  const _RadialGauge({
    required this.label,
    required this.value,
    required this.unit,
    required this.max,
  });

  @override
  Widget build(BuildContext context) {
    final percentage = (value / max * 100).clamp(0, 100);

    return GlassContainer(
      padding: const EdgeInsets.all(16),
      borderRadius: 12,
      child: Column(
        children: [
          SizedBox(
            height: 60,
            width: 60,
            child: Stack(
              children: [
                PieChart(
                  PieChartData(
                    sectionsSpace: 0,
                    centerSpaceRadius: 22,
                    startDegreeOffset: -90,
                    sections: [
                      PieChartSectionData(
                        color: AppColors.safeGreen,
                        value: percentage.toDouble(),
                        title: '',
                        radius: 5,
                      ),
                      PieChartSectionData(
                        color: AppColors.outline.withOpacity(0.2),
                        value: (100 - percentage).toDouble(),
                        title: '',
                        radius: 5,
                      ),
                    ],
                  ),
                ),
                Center(
                  child: Text(
                    value < 100 ? value.toStringAsFixed(1) : value.toInt().toString(),
                    style: GoogleFonts.jetBrainsMono(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: GoogleFonts.inter(fontSize: 7, fontWeight: FontWeight.w900, color: AppColors.mutedIcon, letterSpacing: 1),
          ),
          Text(
            unit,
            style: GoogleFonts.inter(fontSize: 7, color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }
}

class _ExecutionCard extends StatelessWidget {
  final Map<String, dynamic> execution;

  const _ExecutionCard({required this.execution});

  @override
  Widget build(BuildContext context) {
    final exitCode = execution['exit_code'] as int;
    final isSuccess = exitCode == 0;
    final compute = (execution['host_compute'] as String).toUpperCase();
    final usage = execution['resource_usage'] as Map;
    final memoryUsed = (usage['memory_used_mb'] as num).toDouble();
    final totalTime = (execution['total_time_ms'] as num).toDouble();

    final computeColor = {
      'CPU': AppColors.infoBlue,
      'GPU': AppColors.safeGreen,
      'NPU': AppColors.warningAmber,
    }[compute] ?? AppColors.mutedIcon;

    return GlassContainer(
      padding: const EdgeInsets.all(16),
      borderRadius: 12,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      execution['selected_device_name'],
                      style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      execution['cmd'],
                      style: GoogleFonts.jetBrainsMono(fontSize: 9, color: AppColors.textSecondary),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                decoration: BoxDecoration(
                  color: isSuccess ? AppColors.safeGreen.withOpacity(0.1) : AppColors.primaryRed.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: isSuccess ? AppColors.safeGreen.withOpacity(0.3) : AppColors.primaryRed.withOpacity(0.3)),
                ),
                child: Text(
                  'EXIT $exitCode',
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 8,
                    fontWeight: FontWeight.w800,
                    color: isSuccess ? AppColors.safeGreen : AppColors.primaryRed,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              _Capsule(icon: LucideIcons.cpu, label: compute, color: computeColor),
              const SizedBox(width: 8),
              _Capsule(icon: LucideIcons.database, label: '${memoryUsed.toStringAsFixed(1)} MB', color: AppColors.infoBlue),
              const SizedBox(width: 8),
              _Capsule(icon: LucideIcons.clock, label: '${totalTime.toStringAsFixed(1)} ms', color: AppColors.warningAmber),
            ],
          ),
        ],
      ),
    );
  }
}

class _Capsule extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;

  const _Capsule({required this.icon, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.surface2,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 8, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: GoogleFonts.inter(fontSize: 8, fontWeight: FontWeight.w800, color: color),
          ),
        ],
      ),
    );
  }
}
