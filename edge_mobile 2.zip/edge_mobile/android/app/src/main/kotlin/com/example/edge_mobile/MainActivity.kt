package com.example.edge_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
